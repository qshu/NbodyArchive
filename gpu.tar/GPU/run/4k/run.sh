time ../nbody6.gpu < rs > GPU

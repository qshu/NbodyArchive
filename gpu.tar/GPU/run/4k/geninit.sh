#!/bin/sh
../nbody6.gpu < input > INIT
mv fort.2 fort.1

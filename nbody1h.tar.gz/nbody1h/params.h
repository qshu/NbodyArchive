*       NBODY1 parameters.
*       ------------------
*
      integer NMAX
      PARAMETER  (NMAX=2000)
*
*
*       ----------------------------------------
*       NMAX    Maximum number of bodies.
*       ----------------------------------------
*
